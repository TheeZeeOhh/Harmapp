# ThriveBMore 🌈

**Empower. Connect. Transform.**

Welcome to **ThriveBMore** — Baltimore’s revolutionary LGBTQ+ empowerment hub in digital form. Built by and for the community, this platform connects trans and queer lives to real-time resources, peer support, wellness, legal tools, emergency aid, and collective joy.

[![Deploy to Heroku](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/your-username/thrivebmore)

---

## 💡 Why ThriveBMore?

Because we are **done surviving.** It’s time to **THRIVE**.

- 📅 Real-Time Events
- 🧘🏾‍♀️ Health & Wellness Tools
- 👥 Peer Support Forums
- ⚖️ Legal + Financial Aid Access
- 🛑 Emergency Resource Navigation
- 🔊 Community Stories & Empowerment
- 🧠 Identity Development & Guidance

## 🚀 Getting Started

```bash
git clone https://github.com/your-username/thrivebmore.git
cd thrivebmore
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
flask run
```

## 🧪 Running Tests

```bash
pytest
```

## 📄 License

MIT License. Use it. Remix it. Just don’t gentrify it. 😉

## ✊ Made with love by Aziza Okoro
Trans femme, AfroGoth Domme, and unstoppable architect of liberation.
